import customer_details
import mech_type
import parts
import tax
import sale
import email
#import Aadhar
import search
import dddd
import service


