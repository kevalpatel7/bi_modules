from odoo import fields,models,api, _





class service(models.Model):
	
	_name="service.details"
	_description="details of Mechanic" 



	name=fields.Selection((('Servicing','Servicing'), ('Reparing','Reparing'),('Washing','Washing'),('Painting','Painting')),
                   string='select Servicing',required=True)

	code=fields.Char(string="code")



	@api.multi
	def action_cancel(self):
		print "==========action_cancel====service=============="
		for service in self:
			garage_id = self.env['mech.details'].search([])
			garage_id.action_cancel()
		return

