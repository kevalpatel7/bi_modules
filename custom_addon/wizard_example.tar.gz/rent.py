from odoo import fields,models,api, _


class rent(models.Model):

	_name='car.rent'


	@api.multi
	@api.onchange('rent_price','payment')
	def _cal_bill(self):
		total=0
		for rent in self:
			if not rent:
				return
			total=rent.rent_price-rent.payment
			rent.remaining=total




	name=fields.Selection([('car','car'),('bike','bike')], default='car',string='Select type',required=True)
	Model_car=fields.Selection([('bmw','BMW'),('fortuner','Fortuner'),('audi','Audi'),('jaguar','Jaguar')],string='Select car',required=True)
	Model_bike=fields.Selection([('bmw','BMW'),('honda','Honda'),('ducati','Ducati'),('harley davidson','Harley davidson')],string='Select bike')
	customer=fields.Many2one('customer.details',String='customer',required=True)
	rent_price=fields.Integer(string=' Set rent',required=True)
	Date=fields.Date(string='Pickup date')
	Days=fields.Integer(string='Days for rent ')
	number=fields.Char(string='Number plate')
	payment=fields.Integer(string='Advance payment',required=True)
	remaining=fields.Integer( compute='_cal_bill',string='remaining bill')
	return_date=fields.Date(string='Dropoff date')
	licence=fields.Binary(string='Upload your licence',required=True)
	city=fields.Selection([('a','Ahmedabad'), ('g','Goa'),('d','Delhi')],related='customer.city',string='Pickup city')
	cityd=fields.Selection([('Ahmedabad','Ahmedabad'),('Goa','Goa'),('Delhi','Delhi')],string='Dropoff city',required=True)








