import customer_details
import mech_type
import parts
import tax
import sale
import email
#import Aadhar
import search
import dddd
import service
import worker
import rent
#import product
import car
import create_part
import car_receive
#import bike


